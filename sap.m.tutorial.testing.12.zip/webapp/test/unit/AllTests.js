sap.ui.define([
	"./model/models",
	"./model/formatter",
	"./model/FlaggedType"
], function() {
	"use strict";
});
